dojo.provide("dojox.grid.compat._grid.drag");

// summary:
//	utility functions for dragging as used in grid.
// begin closure
(function(){

var dgdrag = dojox.grid.drag = {};

dgdrag.dragging = false;
dgdrag.hysteresis = 2;

dgdrag.capture = function(inElement) {
	//console.debug('dojox.grid.drag.capture');
	if (inElement.setCapture)
		inElement.setCapture();
	else {
		document.addEventListener("mousemove", inElement.onmousemove, true);
		document.addEventListener("mouseup", inElement.onmouseup, true);
		document.addEventListener("click", inElement.onclick, true);
	}
}

dgdrag.release = function(inElement) {
	//console.debug('dojox.grid.drag.release');
	if(inElement.releaseCapture){
		inElement.releaseCapture();
	}else{
		document.removeEventListener("click", inElement.onclick, true);
		document.removeEventListener("mouseup", inElement.onmouseup, true);
		document.removeEventListener("mousemove", inElement.onmousemove, true);
	}
}

dgdrag.start = function(inElement, inOnDrag, inOnEnd, inEvent, inOnStart){
	if(/*dgdrag.elt ||*/ !inElement !ig.e�if(/*dgdrag.eltlr j=0, il
	// 	
}

dg !ig: bad if iteturnsorw = this.��ve, l             =0, il
	.eltlr j=Btener("mumn in a grid layout has a cell obll));
	/ 	
} function.elt 
	//consolno, i;
	th :inElemen.elt 
	//consolno, i;
	son(thg, inOnEnd.elt 
	//consolno, i;
	old, -1)istener("mousemove", inE;
	oldup)istener("mousemoveu, i;
	old
			//entListener("click    ut has a clow: hidInde( inOnDle(inD'croeenX'ent, inOnDr (f, inOnDr.croeenX :s, cellut has a clow: hidYnde( inOnDle(inD'croeenY'ent, inOnDr (f, inOnDr.croeenY :s, cellut has a  true)eex) : as a clow: hidwIdes, cellut stener("mousemove", ix)  as a cemove", iut stener("mousemoveu,x)  as a cemoveu,ut ntListener("clickx)  as a cclickut ag.hysteresis (r("mumn inlutousemove, th ;
	}
}

dgdr)function(inElement        dojo.ove, th notifclick, true);
(r("mumn inluter("mumn imousemove", ix)  as a c// 		paold, -1uter("mumn imousemoveu,x)  as a c// 		paolduputer("mumn imr("clickx)  as a c// 		paoldclickuter("mumn imhis.lastOvent: fnEvehas a  true)ee"onblu as a c// 		path this.grid.fi grit: fnox.grid.drag = {};

dgdr.onmousemove, thicD ima;
	}
}

dgdrn: functioninDrag.scrollL =, inOnDr.croeenX - has a clow: hidI;oninDrag.scrollYnd, inOnDr.croeenY - has a clow: hidYutousemove, mn se{
d;
	}
}

dgdrn: function l    lIndex){
	inDrag.scrollL nelIndex){
	inDrag.scrollY) > g.dragging = falsutous as a cemove", i;
	}
}

dgdrn: functioninDrag.nEvent){resDrag.rn: funct;onize: funcDrag.rn: funct;onemove, thicD imarn: funct;od.dra!has a  true)ee"&&(emove, mn se{
drn: functRowInu as a c// 		p true)rn: funct;od has a  true)eex)etCellX(e
nEvehas a  true)eeowInu as a c// 		p s a rn: funct;.onmousemove, emoveu,x
	}
}

dgdrn: func)function(inElement        dojo.ove, emoveEvet;onize: funcDrag.rent){resDrag.rn: functt;onemove,ath thisousemove, clickx) }
}

dgdrn: func)fonize: funcDrag.rent){resDrag.rn: functt;on//emove,ath thisous})thiing th ed in gr);
			});
		}
	}
});
