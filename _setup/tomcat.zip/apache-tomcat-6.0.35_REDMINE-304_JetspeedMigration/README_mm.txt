
Dies ist der DEFAULT Tomcat, der zum J22 Jetexpress Tutorial Tomcat wurde und jetzt von diesem kopiert zum Tomcat f�r's PortalU auf Jetspeed 2.3 (InGrid 3.5.)


- Run
        cd C:\Users\Public\Programme\apache-tomcat-6.0.35_REDMINE-304_JetspeedMigration\bin
        catalina.bat run

        http://localhost:8082
